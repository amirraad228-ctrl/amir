#!/usr/bin/env python3
"""Shared device catalog server for the DeviceSpecs app (stdlib only).

Run:   CATALOG_TOKEN=secret CATALOG_DB=catalog.db python3 catalog_server.py 8080
Put it behind HTTPS (e.g. a reverse proxy such as Caddy/nginx); the Android app only
accepts https:// catalog URLs.

API
  GET  /health
  GET  /v1/devices?since=<seq>&limit=<n>   -> JSON array, ordered by seq
  POST /v1/devices                         -> body: JSON array of devices (upsert, newer updatedAt wins)
Auth: header "X-Api-Key: <token>" when CATALOG_TOKEN is set.
"""
import hmac
import json
import os
import sqlite3
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

DB_PATH = os.environ.get("CATALOG_DB", "catalog.db")
TOKEN = os.environ.get("CATALOG_TOKEN", "")
MAX_BODY = 512 * 1024
MAX_ITEMS_PER_POST = 100
MAX_PAGE = 500
CATEGORIES = {"phone", "laptop", "other"}
USAGE = {"gaming", "office", "student", "creative", "programming", "photography",
         "battery", "portable", "budget"}

_lock = threading.Lock()


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS devices ("
        " key TEXT PRIMARY KEY,"
        " seq INTEGER NOT NULL,"
        " updated_at INTEGER NOT NULL,"
        " body TEXT NOT NULL)"
    )
    conn.execute("CREATE INDEX IF NOT EXISTS idx_seq ON devices(seq)")
    return conn


def norm_key(name):
    return "".join(ch for ch in name.lower() if ch.isalnum() or ch == "+")


def clean_str(v, limit):
    if not isinstance(v, str):
        raise ValueError("expected string")
    v = v.strip()
    if len(v) > limit:
        raise ValueError("string too long")
    return v


def validate(item):
    """Return a sanitized device dict or raise ValueError."""
    if not isinstance(item, dict):
        raise ValueError("item must be an object")
    name = clean_str(item.get("name", ""), 200)
    key = norm_key(name)
    if len(key) < 2:
        raise ValueError("bad name")
    brand = clean_str(item.get("brand", ""), 60)
    category = item.get("category", "other")
    if category not in CATEGORIES:
        category = "other"
    specs_in = item.get("specs")
    if not isinstance(specs_in, dict) or not specs_in or len(specs_in) > 20:
        raise ValueError("bad specs")
    specs = {}
    for sec, rows in specs_in.items():
        if not isinstance(rows, dict) or len(rows) > 60:
            raise ValueError("bad section")
        specs[clean_str(sec, 60)] = {
            clean_str(k, 80): clean_str(str(v) if not isinstance(v, str) else v, 300)
            for k, v in rows.items()
        }
    sources_in = item.get("sources", [])
    if not isinstance(sources_in, list) or len(sources_in) > 10:
        raise ValueError("bad sources")
    sources = [clean_str(s, 300) for s in sources_in
               if isinstance(s, str) and s.startswith(("http://", "https://"))]
    usage_in = item.get("usage", [])
    if not isinstance(usage_in, list):
        raise ValueError("bad usage")
    usage = sorted({u for u in usage_in if isinstance(u, str) and u in USAGE})
    now_ms = int(time.time() * 1000)
    updated = item.get("updatedAt", now_ms)
    if not isinstance(updated, int) or updated <= 0:
        updated = now_ms
    updated = min(updated, now_ms + 24 * 3600 * 1000)  # no far-future timestamps
    return {
        "key": key, "name": name, "brand": brand, "category": category,
        "specs": specs, "sources": sources, "usage": usage, "updatedAt": updated,
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "DeviceCatalog/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def _send(self, code, payload):
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _authorized(self):
        if not TOKEN:
            return True
        given = self.headers.get("X-Api-Key", "")
        return hmac.compare_digest(given.encode(), TOKEN.encode())

    def do_GET(self):
        url = urlparse(self.path)
        if url.path == "/health":
            return self._send(200, {"ok": True})
        if url.path != "/v1/devices":
            return self._send(404, {"error": "not found"})
        if not self._authorized():
            return self._send(401, {"error": "unauthorized"})
        q = parse_qs(url.query)
        try:
            since = int(q.get("since", ["0"])[0])
            limit = max(1, min(int(q.get("limit", [str(MAX_PAGE)])[0]), MAX_PAGE))
        except ValueError:
            return self._send(400, {"error": "bad query"})
        with _lock, db() as conn:
            rows = conn.execute(
                "SELECT seq, body FROM devices WHERE seq > ? ORDER BY seq LIMIT ?",
                (since, limit),
            ).fetchall()
        out = []
        for seq, body in rows:
            d = json.loads(body)
            d["seq"] = seq
            out.append(d)
        self._send(200, out)

    def do_POST(self):
        url = urlparse(self.path)
        if url.path != "/v1/devices":
            return self._send(404, {"error": "not found"})
        if not self._authorized():
            return self._send(401, {"error": "unauthorized"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            return self._send(400, {"error": "bad length"})
        if length <= 0 or length > MAX_BODY:
            return self._send(413, {"error": "body too large or empty"})
        try:
            items = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(items, list) or len(items) > MAX_ITEMS_PER_POST:
                raise ValueError("expected a list of up to %d items" % MAX_ITEMS_PER_POST)
            clean = [validate(i) for i in items]
        except (ValueError, UnicodeDecodeError) as e:
            return self._send(400, {"error": str(e)})
        accepted = 0
        with _lock, db() as conn:
            next_seq = (conn.execute("SELECT COALESCE(MAX(seq), 0) FROM devices").fetchone()[0])
            for d in clean:
                row = conn.execute(
                    "SELECT updated_at FROM devices WHERE key = ?", (d["key"],)
                ).fetchone()
                if row is not None and row[0] >= d["updatedAt"]:
                    continue  # existing entry is as new or newer
                next_seq += 1
                conn.execute(
                    "INSERT OR REPLACE INTO devices(key, seq, updated_at, body) VALUES (?,?,?,?)",
                    (d["key"], next_seq, d["updatedAt"], json.dumps(d, ensure_ascii=False)),
                )
                accepted += 1
        self._send(200, {"accepted": accepted, "received": len(clean)})


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    host = os.environ.get("CATALOG_HOST", "127.0.0.1")
    db().close()
    print("Catalog server on %s:%d (db=%s, auth=%s)" % (host, port, DB_PATH, "on" if TOKEN else "OFF"))
    ThreadingHTTPServer((host, port), Handler).serve_forever()


if __name__ == "__main__":
    main()
