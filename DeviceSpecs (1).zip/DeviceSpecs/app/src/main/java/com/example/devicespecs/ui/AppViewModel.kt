package com.example.devicespecs.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.devicespecs.R
import com.example.devicespecs.data.AppDb
import com.example.devicespecs.data.DeviceEntity
import com.example.devicespecs.data.NoKeyException
import com.example.devicespecs.data.NotFoundException
import com.example.devicespecs.data.Repository
import com.example.devicespecs.data.SettingsStore
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen { SEARCH, LIBRARY, PHONES, LAPTOPS, COMPARE, SETTINGS }

enum class Target { DETAILS, A, B }

data class UiState(
    val screen: Screen = Screen.SEARCH,
    /** برند انتخاب‌شده در صفحه گوشی/لپ‌تاپ؛ "*" یعنی همه برندها. */
    val brand: String? = null,
    /** فیلتر کاربری (مثلاً gaming)؛ null یعنی همه. */
    val usage: String? = null,
    val query: String = "",
    val suggestions: List<DeviceEntity> = emptyList(),
    val loading: Boolean = false,
    val errorRes: Int? = null,
    val errorDetail: String? = null,
    val current: DeviceEntity? = null,
    val slotA: DeviceEntity? = null,
    val slotB: DeviceEntity? = null,
    val showConsent: Boolean = false,
    val syncing: Boolean = false,
    val lastSyncAdded: Int? = null,
    val syncError: String? = null,
)

private const val STALE_MS = 30L * 24 * 60 * 60 * 1000
private const val STALE_REFRESH_PER_LAUNCH = 3

class AppViewModel(app: Application) : AndroidViewModel(app) {
    val settings = SettingsStore(app)
    private val repo = Repository(AppDb.get(app).dao(), settings)

    val library = repo.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var ui by mutableStateOf(UiState())
        private set

    var appearance by mutableStateOf(
        Appearance(settings.language, settings.themeMode, settings.accent, settings.textScale)
    )
        private set

    private var pending: (() -> Unit)? = null

    init {
        // هر بار که برنامه اجرا می‌شود (و اینترنت مجاز است) کتابخانه با کاتالوگ همگام می‌شود.
        syncOnLaunch()
    }

    // ------------------------------------------------------------------ ناوبری و فیلتر

    fun go(screen: Screen) {
        ui = ui.copy(screen = screen, brand = null, usage = null, errorRes = null, errorDetail = null)
    }

    fun selectBrand(brand: String?) {
        ui = ui.copy(brand = brand, usage = null, errorRes = null, errorDetail = null)
    }

    fun setUsage(tag: String?) {
        ui = ui.copy(usage = tag)
    }

    fun onQuery(q: String) {
        ui = ui.copy(query = q)
        viewModelScope.launch {
            val s = if (q.isBlank()) emptyList() else repo.suggest(q)
            ui = ui.copy(suggestions = s)
        }
    }

    // ------------------------------------------------------------------ ظاهر و زبان

    fun updateAppearance(a: Appearance) {
        settings.language = a.language
        settings.themeMode = a.themeMode
        settings.accent = a.accent
        settings.textScale = a.textScale
        appearance = a
    }

    // ------------------------------------------------------------------ نمایش مدل

    /** اول کتابخانه (سریع)، بعد در صورت نبود، جست‌وجوی آنلاین. */
    fun resolve(query: String, target: Target) {
        val q = query.trim()
        if (q.isEmpty()) return
        viewModelScope.launch {
            val local = repo.findLocal(q)
            if (local != null) {
                repo.touch(local)
                place(local, target)
                refreshIfStale(local, target)
                return@launch
            }
            requireOnline { fetchAndPlace(q, target) }
        }
    }

    fun openLocal(d: DeviceEntity, target: Target) {
        viewModelScope.launch {
            repo.touch(d)
            place(d, target)
            refreshIfStale(d, target)
        }
    }

    fun refresh(d: DeviceEntity, target: Target) {
        requireOnline { fetchAndPlace(d.name, target, d) }
    }

    fun delete(d: DeviceEntity) {
        viewModelScope.launch {
            repo.delete(d)
            ui = ui.copy(
                current = ui.current?.takeIf { it.id != d.id },
                slotA = ui.slotA?.takeIf { it.id != d.id },
                slotB = ui.slotB?.takeIf { it.id != d.id },
            )
        }
    }

    // ------------------------------------------------------------------ رضایت و آنلاین

    fun acceptConsent() {
        settings.consent = true
        ui = ui.copy(showConsent = false)
        pending?.invoke()
        pending = null
        syncOnLaunch()
    }

    fun declineConsent() {
        pending = null
        ui = ui.copy(showConsent = false)
    }

    private fun requireOnline(action: () -> Unit) {
        when {
            !settings.consent -> {
                pending = action
                ui = ui.copy(showConsent = true)
            }
            settings.apiKey.isBlank() -> {
                ui = ui.copy(errorRes = R.string.error_need_key, errorDetail = null)
            }
            else -> action()
        }
    }

    private fun fetchAndPlace(q: String, target: Target, existing: DeviceEntity? = null) {
        viewModelScope.launch {
            ui = ui.copy(loading = true, errorRes = null, errorDetail = null)
            try {
                place(repo.fetchOnline(q, existing), target)
                pushQuietly()
            } catch (e: NoKeyException) {
                ui = ui.copy(errorRes = R.string.error_need_key)
            } catch (e: NotFoundException) {
                ui = ui.copy(errorRes = R.string.error_not_found)
            } catch (e: Exception) {
                ui = ui.copy(errorRes = R.string.error_generic, errorDetail = e.message ?: e.javaClass.simpleName)
            }
            ui = ui.copy(loading = false)
        }
    }

    /** به‌روزرسانی بی‌صدای اطلاعات قدیمی هنگام استفاده. */
    private fun refreshIfStale(d: DeviceEntity, target: Target) {
        if (System.currentTimeMillis() - d.fetchedAt < STALE_MS || !repo.canGoOnline()) return
        viewModelScope.launch {
            try {
                val fresh = repo.fetchOnline(d.name, d)
                // بی‌صدا: صفحه‌ای که کاربر الان در آن است تغییر نمی‌کند.
                ui = when (target) {
                    Target.DETAILS -> if (ui.current?.id == fresh.id) ui.copy(current = fresh) else ui
                    Target.A -> ui.copy(slotA = fresh)
                    Target.B -> ui.copy(slotB = fresh)
                }
                pushQuietly()
            } catch (_: Exception) {
                // نسخه ذخیره‌شده همچنان معتبر است.
            }
        }
    }

    private suspend fun pushQuietly() {
        try {
            repo.pushPending()
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ همگام‌سازی کاتالوگ

    /** دریافت مدل‌های کاربران دیگر، تازه‌سازی چند مدل قدیمی و ارسال تغییرات. */
    fun syncOnLaunch() {
        if (!settings.consent || ui.syncing) return
        viewModelScope.launch {
            ui = ui.copy(syncing = true, syncError = null)
            try {
                val added = repo.sync()
                val refreshed = repo.refreshStale(STALE_REFRESH_PER_LAUNCH, STALE_MS)
                if (refreshed > 0) repo.pushPending()
                ui = ui.copy(lastSyncAdded = added)
            } catch (e: Exception) {
                ui = ui.copy(syncError = e.message ?: e.javaClass.simpleName)
            }
            ui = ui.copy(syncing = false)
        }
    }

    private fun place(d: DeviceEntity, target: Target) {
        ui = when (target) {
            Target.DETAILS -> ui.copy(current = d, screen = Screen.SEARCH, brand = null, usage = null)
            Target.A -> ui.copy(slotA = d)
            Target.B -> ui.copy(slotB = d)
        }
    }
}
