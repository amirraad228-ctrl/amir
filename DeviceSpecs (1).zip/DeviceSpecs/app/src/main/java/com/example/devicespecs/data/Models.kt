package com.example.devicespecs.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer
import kotlinx.serialization.json.Json

val AppJson = Json {
    ignoreUnknownKeys = true
    isLenient = true
}

/** خروجی ساختاریافته‌ای که از هوش مصنوعی می‌گیریم. */
@Serializable
data class SpecResult(
    val name: String = "",
    val brand: String = "",
    val category: String = "other",
    val specs: Map<String, Map<String, String>> = emptyMap(),
    val sources: List<String> = emptyList(),
    val usage: List<String> = emptyList(),
    val error: String? = null,
)

@Entity(tableName = "devices", indices = [Index(value = ["key"], unique = true)])
data class DeviceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,
    val name: String,
    val brand: String = "",
    val category: String,
    val specsJson: String,
    val sourcesJson: String,
    /** برچسب‌های کاربری، جداشده با ویرگول (مثلاً gaming,student). */
    val usage: String = "",
    val fetchedAt: Long,
    val lastUsedAt: Long,
    val useCount: Int = 1,
)

private val specsSerializer =
    MapSerializer(String.serializer(), MapSerializer(String.serializer(), String.serializer()))
private val sourcesSerializer = ListSerializer(String.serializer())

fun encodeSpecs(m: Map<String, Map<String, String>>): String =
    AppJson.encodeToString(specsSerializer, m)

fun encodeSources(l: List<String>): String = AppJson.encodeToString(sourcesSerializer, l)

fun DeviceEntity.specs(): Map<String, Map<String, String>> =
    runCatching { AppJson.decodeFromString(specsSerializer, specsJson) }.getOrDefault(emptyMap())

fun DeviceEntity.sources(): List<String> =
    runCatching { AppJson.decodeFromString(sourcesSerializer, sourcesJson) }.getOrDefault(emptyList())

fun DeviceEntity.usageTags(): List<String> = usage.split(",").filter { it.isNotBlank() }

/** کلید یکتا برای نام مدل: حروف کوچک، بدون فاصله و علامت (به جز +). */
fun normalizeKey(s: String): String =
    s.lowercase().filter { it.isLetterOrDigit() || it == '+' }

@Dao
interface DeviceDao {
    @Query("SELECT * FROM devices ORDER BY lastUsedAt DESC")
    fun observeAll(): Flow<List<DeviceEntity>>

    @Query("SELECT * FROM devices")
    suspend fun all(): List<DeviceEntity>

    @Query("SELECT * FROM devices WHERE `key` = :key LIMIT 1")
    suspend fun byKey(key: String): DeviceEntity?

    @Query(
        "SELECT * FROM devices WHERE `key` LIKE '%' || :key || '%' OR name LIKE '%' || :raw || '%' " +
            "ORDER BY useCount DESC LIMIT 8"
    )
    suspend fun suggest(key: String, raw: String): List<DeviceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(d: DeviceEntity): Long

    @Query("UPDATE devices SET lastUsedAt = :t, useCount = useCount + 1 WHERE id = :id")
    suspend fun touch(id: Long, t: Long)

    @Delete
    suspend fun delete(d: DeviceEntity)
}

@Database(entities = [DeviceEntity::class], version = 2, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): DeviceDao

    companion object {
        @Volatile private var instance: AppDb? = null

        fun get(context: Context): AppDb =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext, AppDb::class.java, "specs.db"
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
    }
}
