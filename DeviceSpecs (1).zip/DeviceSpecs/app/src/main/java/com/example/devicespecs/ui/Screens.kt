package com.example.devicespecs.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.devicespecs.R
import com.example.devicespecs.data.Brands
import com.example.devicespecs.data.DeviceEntity
import com.example.devicespecs.data.Usage
import com.example.devicespecs.data.sources
import com.example.devicespecs.data.specs
import com.example.devicespecs.data.usageTags
import kotlinx.coroutines.launch
import kotlin.math.abs

// ---------------------------------------------------------------------- برچسب‌ها

@Composable
private fun sectionLabel(sec: String): String {
    val id = when (sec) {
        "Display" -> R.string.section_display
        "Processor" -> R.string.section_processor
        "Memory" -> R.string.section_memory
        "Storage" -> R.string.section_storage
        "Camera" -> R.string.section_camera
        "Battery" -> R.string.section_battery
        "Connectivity" -> R.string.section_connectivity
        "Body" -> R.string.section_body
        "Software" -> R.string.section_software
        "Release" -> R.string.section_release
        else -> null
    }
    return if (id != null) stringResource(id) else sec
}

@Composable
private fun usageLabel(tag: String): String {
    val id = when (tag) {
        "gaming" -> R.string.usage_gaming
        "office" -> R.string.usage_office
        "student" -> R.string.usage_student
        "creative" -> R.string.usage_creative
        "programming" -> R.string.usage_programming
        "photography" -> R.string.usage_photography
        "battery" -> R.string.usage_battery
        "portable" -> R.string.usage_portable
        "budget" -> R.string.usage_budget
        else -> null
    }
    return if (id != null) stringResource(id) else tag
}

private fun brandColor(name: String): Color =
    Brands.known(name)?.let { Color(it.color) }
        ?: Color.hsv((abs(name.lowercase().hashCode()) % 360).toFloat(), 0.55f, 0.55f)

@Composable
private fun errorText(errorRes: Int?, detail: String?): String? =
    errorRes?.let { if (detail != null) stringResource(it, detail) else stringResource(it) }

// ---------------------------------------------------------------------- اسکلت اصلی با منوی کناری

private data class NavItem(val screen: Screen, val icon: String, val label: Int)

private val navItems = listOf(
    NavItem(Screen.SEARCH, "🔍", R.string.menu_search),
    NavItem(Screen.LIBRARY, "📚", R.string.menu_library),
    NavItem(Screen.PHONES, "📱", R.string.menu_phones),
    NavItem(Screen.LAPTOPS, "💻", R.string.menu_laptops),
    NavItem(Screen.COMPARE, "⚖️", R.string.menu_compare),
    NavItem(Screen.SETTINGS, "⚙️", R.string.menu_settings),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel) {
    val ui = vm.ui
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    BackHandler(enabled = ui.brand != null) { vm.selectBrand(null) }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(24.dp),
                )
                navItems.forEach { item ->
                    NavigationDrawerItem(
                        label = { Text(stringResource(item.label)) },
                        selected = ui.screen == item.screen,
                        icon = { Text(item.icon) },
                        onClick = {
                            vm.go(item.screen)
                            scope.launch { drawer.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding),
                    )
                }
            }
        },
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        val label = navItems.first { it.screen == ui.screen }.label
                        Text(stringResource(label))
                    },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawer.open() } }) {
                            Text("☰", style = MaterialTheme.typography.titleLarge)
                        }
                    },
                )
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (ui.screen) {
                    Screen.SEARCH -> SearchScreen(vm)
                    Screen.LIBRARY -> LibraryScreen(vm)
                    Screen.PHONES -> CategoryScreen(vm, "phone")
                    Screen.LAPTOPS -> CategoryScreen(vm, "laptop")
                    Screen.COMPARE -> CompareScreen(vm)
                    Screen.SETTINGS -> SettingsScreen(vm)
                }
            }
        }
    }

    if (ui.showConsent) {
        AlertDialog(
            onDismissRequest = { vm.declineConsent() },
            title = { Text(stringResource(R.string.consent_title)) },
            text = { Text(stringResource(R.string.consent_text)) },
            confirmButton = { TextButton(onClick = { vm.acceptConsent() }) { Text(stringResource(R.string.agree)) } },
            dismissButton = { TextButton(onClick = { vm.declineConsent() }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

// ---------------------------------------------------------------------- اجزای مشترک

@Composable
private fun BrandBadge(brand: String, size: Int = 40) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(brandColor(brand)),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            brand.take(2).ifBlank { "?" },
            color = Color.White,
            fontWeight = FontWeight.Bold,
            style = if (size >= 56) MaterialTheme.typography.titleMedium else MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
private fun UsageChips(tags: List<String>, selected: String?, onSelect: (String?) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(stringResource(R.string.usage_title), style = MaterialTheme.typography.labelLarge)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(
                    selected = selected == null,
                    onClick = { onSelect(null) },
                    label = { Text(stringResource(R.string.usage_all)) },
                )
            }
            items(tags) { t ->
                FilterChip(
                    selected = selected == t,
                    onClick = { onSelect(if (selected == t) null else t) },
                    label = { Text(usageLabel(t)) },
                )
            }
        }
    }
}

@Composable
private fun DeviceRow(d: DeviceEntity, onClick: () -> Unit, onDelete: (() -> Unit)? = null) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(
            Modifier.padding(12.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            BrandBadge(d.brand.ifBlank { d.name })
            Column(Modifier.weight(1f)) {
                Text(d.name, fontWeight = FontWeight.Bold)
                val tags = d.usageTags()
                if (tags.isNotEmpty()) {
                    Text(
                        tags.joinToString(" · ") { usageLabel(it) },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Text(stringResource(R.string.uses_count, d.useCount), style = MaterialTheme.typography.bodySmall)
            }
            if (onDelete != null) {
                TextButton(onClick = onDelete) { Text(stringResource(R.string.delete)) }
            }
        }
    }
}

private fun List<DeviceEntity>.matching(
    category: String? = null,
    brand: String? = null,
    usage: String? = null,
    q: String = "",
): List<DeviceEntity> = filter {
    (category == null || it.category == category) &&
        (brand == null || brand == "*" || it.brand.equals(brand, ignoreCase = true)) &&
        (usage == null || usage in it.usageTags()) &&
        (q.isBlank() || it.name.contains(q, ignoreCase = true))
}

// ---------------------------------------------------------------------- جست‌وجو و جزئیات

@Composable
fun SearchScreen(vm: AppViewModel) {
    val ui = vm.ui
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        OutlinedTextField(
            value = ui.query,
            onValueChange = vm::onQuery,
            label = { Text(stringResource(R.string.search_hint)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.resolve(ui.query, Target.DETAILS) }),
        )
        Button(onClick = { vm.resolve(ui.query, Target.DETAILS) }, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.search_button))
        }

        if (ui.suggestions.isNotEmpty()) {
            Text(stringResource(R.string.similar_saved), style = MaterialTheme.typography.labelLarge)
            ui.suggestions.forEach { d -> DeviceRow(d, onClick = { vm.openLocal(d, Target.DETAILS) }) }
        }

        if (ui.loading) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CircularProgressIndicator(Modifier.size(24.dp))
                Text(stringResource(R.string.searching))
            }
        }
        errorText(ui.errorRes, ui.errorDetail)?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        ui.current?.let { d ->
            DeviceDetails(d)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.refresh(d, Target.DETAILS) }) { Text(stringResource(R.string.refresh)) }
                OutlinedButton(onClick = {
                    val url = "https://www.google.com/search?q=" + Uri.encode(d.name + " specs")
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text(stringResource(R.string.open_browser)) }
            }
        }
    }
}

@Composable
fun DeviceDetails(d: DeviceEntity) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            BrandBadge(d.brand.ifBlank { d.name }, 48)
            Text(d.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        val tags = d.usageTags()
        if (tags.isNotEmpty()) {
            Text(
                tags.joinToString(" · ") { usageLabel(it) },
                color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        d.specs().forEach { (section, rows) ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(sectionLabel(section), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    rows.forEach { (k, v) ->
                        Row(Modifier.fillMaxWidth()) {
                            Text(k, Modifier.weight(0.4f), style = MaterialTheme.typography.bodySmall)
                            Text(v, Modifier.weight(0.6f), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
        val src = d.sources()
        if (src.isNotEmpty()) {
            Text(stringResource(R.string.sources), style = MaterialTheme.typography.labelLarge)
            src.take(5).forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
    }
}

// ---------------------------------------------------------------------- کتابخانه

@Composable
fun LibraryScreen(vm: AppViewModel) {
    val items by vm.library.collectAsState()
    val ui = vm.ui
    var filter by remember { mutableStateOf("") }
    val shown = items.matching(usage = ui.usage, q = filter)
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(stringResource(R.string.library_count, items.size), style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = filter, onValueChange = { filter = it },
            label = { Text(stringResource(R.string.filter_hint)) }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        UsageChips(Usage.all, ui.usage, vm::setUsage)
        if (shown.isEmpty()) Text(stringResource(R.string.no_devices))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(shown, key = { it.id }) { d ->
                DeviceRow(d, onClick = { vm.openLocal(d, Target.DETAILS) }, onDelete = { vm.delete(d) })
            }
        }
    }
}

// ---------------------------------------------------------------------- گوشی / لپ‌تاپ: برندها و فیلتر کاربری

@Composable
fun CategoryScreen(vm: AppViewModel, category: String) {
    val ui = vm.ui
    val lib by vm.library.collectAsState()
    val inCategory = lib.matching(category = category)

    val knownBrands = (if (category == "phone") Brands.phones else Brands.laptops).map { it.id }
    val extras = inCategory.map { it.brand }
        .filter { b -> b.isNotBlank() && knownBrands.none { it.equals(b, ignoreCase = true) } }
        .distinct()
    val brands = knownBrands + extras

    val brand = ui.brand
    if (brand == null) {
        // شبکه برندها
        Column(Modifier.fillMaxSize()) {
            Text(
                stringResource(R.string.brands_title),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp),
            )
            LazyVerticalGrid(
                columns = GridCells.Adaptive(96.dp),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    BrandTile(
                        label = stringResource(R.string.all_brands),
                        badge = "★",
                        color = MaterialTheme.colorScheme.primary,
                        count = inCategory.size,
                        onClick = { vm.selectBrand("*") },
                    )
                }
                gridItems(brands) { b ->
                    BrandTile(
                        label = b,
                        badge = b.take(2),
                        color = brandColor(b),
                        count = inCategory.count { it.brand.equals(b, ignoreCase = true) },
                        onClick = { vm.selectBrand(b) },
                    )
                }
            }
        }
    } else {
        // فهرست دستگاه‌های یک برند با فیلتر کاربری
        var text by remember(brand) { mutableStateOf("") }
        val prefix = if (brand == "*") "" else "$brand "
        val shown = inCategory.matching(brand = brand, usage = ui.usage)
        val tags = if (category == "phone") Usage.phone else Usage.laptop
        Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { vm.selectBrand(null) }) { Text(stringResource(R.string.back_to_brands)) }
                if (brand != "*") {
                    BrandBadge(brand, 32)
                    Spacer(Modifier.size(8.dp))
                    Text(brand, style = MaterialTheme.typography.titleMedium)
                }
            }
            UsageChips(tags, ui.usage, vm::setUsage)
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                label = { Text(stringResource(R.string.add_model_hint)) }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { vm.resolve(prefix + text, Target.DETAILS) }),
            )
            if (ui.loading) CircularProgressIndicator(Modifier.size(24.dp))
            errorText(ui.errorRes, ui.errorDetail)?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            if (shown.isEmpty()) Text(stringResource(R.string.no_devices))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown, key = { it.id }) { d ->
                    DeviceRow(d, onClick = { vm.openLocal(d, Target.DETAILS) })
                }
            }
        }
    }
}

@Composable
private fun BrandTile(label: String, badge: String, color: Color, count: Int, onClick: () -> Unit) {
    Column(
        Modifier.clickable(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(color), contentAlignment = Alignment.Center) {
            Text(badge, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        }
        Text(label, maxLines = 1, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
        Text(
            stringResource(R.string.devices_count, count),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// ---------------------------------------------------------------------- مقایسه

@Composable
fun CompareScreen(vm: AppViewModel) {
    val ui = vm.ui
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text(stringResource(R.string.compare_title), style = MaterialTheme.typography.titleMedium)
        Slot(stringResource(R.string.model_first), ui.slotA, vm, Target.A)
        Slot(stringResource(R.string.model_second), ui.slotB, vm, Target.B)
        if (ui.loading) CircularProgressIndicator()
        errorText(ui.errorRes, ui.errorDetail)?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        val a = ui.slotA
        val b = ui.slotB
        if (a != null && b != null) CompareTable(a, b)
    }
}

@Composable
private fun Slot(title: String, d: DeviceEntity?, vm: AppViewModel, target: Target) {
    var text by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val lib by vm.library.collectAsState()
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("$title: ${d?.name ?: stringResource(R.string.not_selected)}", fontWeight = FontWeight.Bold)
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                label = { Text(stringResource(R.string.add_new_model)) }, singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.resolve(text, target); text = "" }) { Text(stringResource(R.string.add)) }
                Box {
                    OutlinedButton(onClick = { menu = true }) { Text(stringResource(R.string.from_library)) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        lib.forEach { item ->
                            DropdownMenuItem(
                                text = { Text(item.name) },
                                onClick = { menu = false; vm.openLocal(item, target) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CompareTable(a: DeviceEntity, b: DeviceEntity) {
    val sa = a.specs()
    val sb = b.specs()
    val sections = (sa.keys + sb.keys).distinct()
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Spacer(Modifier.weight(0.28f))
            Text(a.name, Modifier.weight(0.36f), fontWeight = FontWeight.Bold)
            Text(b.name, Modifier.weight(0.36f), fontWeight = FontWeight.Bold)
        }
        sections.forEach { sec ->
            Text(
                sectionLabel(sec), Modifier.padding(top = 8.dp), fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
            )
            val ra = sa[sec].orEmpty()
            val rb = sb[sec].orEmpty()
            (ra.keys + rb.keys).distinct().forEach { k ->
                val va = ra[k] ?: "—"
                val vb = rb[k] ?: "—"
                val color = if (va != vb) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface
                Row(Modifier.fillMaxWidth()) {
                    Text(k, Modifier.weight(0.28f), style = MaterialTheme.typography.bodySmall)
                    Text(va, Modifier.weight(0.36f), color = color, style = MaterialTheme.typography.bodyMedium)
                    Text(vb, Modifier.weight(0.36f), color = color, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------- تنظیمات

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun RadioRow(selected: Boolean, label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val s = vm.settings
    val ui = vm.ui
    val a = vm.appearance
    var provider by remember { mutableStateOf(s.provider) }
    var key by remember { mutableStateOf(s.apiKey) }
    var model by remember { mutableStateOf(s.model) }
    var consent by remember { mutableStateOf(s.consent) }
    var catUrl by remember { mutableStateOf(s.catalogUrl) }
    var catToken by remember { mutableStateOf(s.catalogToken) }
    var share by remember { mutableStateOf(s.shareToCatalog) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        // --- ظاهر و زبان
        SectionTitle(stringResource(R.string.appearance_title))
        Text(stringResource(R.string.language_title), style = MaterialTheme.typography.labelLarge)
        RadioRow(a.language == "system", stringResource(R.string.lang_system)) { vm.updateAppearance(a.copy(language = "system")) }
        RadioRow(a.language == "en", stringResource(R.string.lang_en)) { vm.updateAppearance(a.copy(language = "en")) }
        RadioRow(a.language == "fa", stringResource(R.string.lang_fa)) { vm.updateAppearance(a.copy(language = "fa")) }

        Text(stringResource(R.string.theme_title), style = MaterialTheme.typography.labelLarge)
        RadioRow(a.themeMode == "system", stringResource(R.string.theme_system)) { vm.updateAppearance(a.copy(themeMode = "system")) }
        RadioRow(a.themeMode == "light", stringResource(R.string.theme_light)) { vm.updateAppearance(a.copy(themeMode = "light")) }
        RadioRow(a.themeMode == "dark", stringResource(R.string.theme_dark)) { vm.updateAppearance(a.copy(themeMode = "dark")) }

        Text(stringResource(R.string.accent_title), style = MaterialTheme.typography.labelLarge)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 4.dp)) {
            items(AccentPresets) { c ->
                val selected = a.accent == c
                Box(
                    Modifier.size(40.dp).clip(CircleShape)
                        .background(if (c == 0L) MaterialTheme.colorScheme.surfaceVariant else Color(c))
                        .border(
                            if (selected) BorderStroke(3.dp, MaterialTheme.colorScheme.onSurface) else BorderStroke(0.dp, Color.Transparent),
                            CircleShape,
                        )
                        .clickable { vm.updateAppearance(a.copy(accent = c)) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (c == 0L) Text("✦")
                }
            }
        }
        Text(stringResource(R.string.accent_dynamic) + ": ✦", style = MaterialTheme.typography.bodySmall)

        Text(stringResource(R.string.text_size), style = MaterialTheme.typography.labelLarge)
        Slider(
            value = a.textScale,
            onValueChange = { vm.updateAppearance(a.copy(textScale = it)) },
            valueRange = 0.85f..1.3f,
        )

        // --- هوش مصنوعی
        SectionTitle(stringResource(R.string.settings_ai))
        RadioRow(provider == "gemini", stringResource(R.string.provider_gemini)) { provider = "gemini"; s.provider = "gemini" }
        RadioRow(provider == "openai", stringResource(R.string.provider_openai)) { provider = "openai"; s.provider = "openai" }
        OutlinedTextField(
            value = key, onValueChange = { key = it; s.apiKey = it },
            label = { Text(stringResource(R.string.api_key)) }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = model, onValueChange = { model = it; s.model = it },
            label = { Text(stringResource(R.string.model_name)) }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = consent, onCheckedChange = { consent = it; s.consent = it; if (it) vm.syncOnLaunch() })
            Text(stringResource(R.string.allow_internet), Modifier.weight(1f))
        }
        Text(stringResource(R.string.settings_note), style = MaterialTheme.typography.bodySmall)

        // --- کاتالوگ مشترک
        SectionTitle(stringResource(R.string.catalog_title))
        OutlinedTextField(
            value = catUrl, onValueChange = { catUrl = it; s.catalogUrl = it },
            label = { Text(stringResource(R.string.catalog_url)) }, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = catToken, onValueChange = { catToken = it; s.catalogToken = it },
            label = { Text(stringResource(R.string.catalog_token)) }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(checked = share, onCheckedChange = { share = it; s.shareToCatalog = it })
            Text(stringResource(R.string.catalog_share), Modifier.weight(1f))
        }
        Text(stringResource(R.string.catalog_note), style = MaterialTheme.typography.bodySmall)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { vm.syncOnLaunch() }, enabled = !ui.syncing && consent) {
                Text(stringResource(R.string.sync_now))
            }
            if (ui.syncing) {
                CircularProgressIndicator(Modifier.size(20.dp))
                Text(stringResource(R.string.syncing))
            }
        }
        ui.lastSyncAdded?.let { Text(stringResource(R.string.sync_added, it), style = MaterialTheme.typography.bodySmall) }
        ui.syncError?.let {
            Text(stringResource(R.string.sync_failed, it), color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(24.dp))
    }
}
