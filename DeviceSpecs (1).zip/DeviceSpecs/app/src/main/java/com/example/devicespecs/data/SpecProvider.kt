package com.example.devicespecs.data

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.add
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.Json

interface SpecProvider {
    suspend fun fetch(query: String): SpecResult
}

private fun buildPrompt(query: String): String = """
You are a hardware specifications assistant. Search the web for the exact, current specifications of this device: "$query".
Prefer reliable sources (manufacturer website, GSMArena, NotebookCheck, etc.).
Reply with ONLY one JSON object, no markdown and no extra text, in this shape:
{"name":"<full official name including brand>","brand":"<brand, e.g. Apple, Samsung, Dell, Lenovo>","category":"phone" or "laptop" or "other","specs":{"Display":{"Size":"..."},"Processor":{},"Memory":{},"Storage":{},"Camera":{},"Battery":{},"Connectivity":{},"Body":{},"Software":{},"Release":{}},"usage":["gaming"],"sources":["https://..."]}
Use exactly these English section names, short English attribute names, and concise values (strings).
"usage" lists what this device is genuinely well suited for, chosen ONLY from: gaming, office, student, creative, programming, photography, battery, portable, budget (phones: gaming, photography, battery, office, budget; laptops: gaming, office, student, creative, programming, portable, budget). Use an empty list if unsure.
Omit unknown fields and never invent values.
If the device does not exist or you cannot find it, reply {"error":"not found"}.
""".trimIndent()

internal suspend fun httpPost(url: String, headers: Map<String, String>, body: String): String =
    withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20_000
            c.readTimeout = 90_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = (stream?.bufferedReader()?.use { it.readText() }).orEmpty()
            if (code !in 200..299) throw IOException("خطای سرور ($code): ${text.take(200)}")
            text
        } finally {
            c.disconnect()
        }
    }

private fun parseResult(text: String): SpecResult {
    val start = text.indexOf('{')
    val end = text.lastIndexOf('}')
    if (start < 0 || end <= start) throw IOException("پاسخ هوش مصنوعی قابل خواندن نبود")
    return AppJson.decodeFromString(SpecResult.serializer(), text.substring(start, end + 1))
}

class GeminiProvider(private val apiKey: String, private val model: String) : SpecProvider {
    override suspend fun fetch(query: String): SpecResult {
        val body = buildJsonObject {
            put("contents", buildJsonArray {
                add(buildJsonObject {
                    put("parts", buildJsonArray {
                        add(buildJsonObject { put("text", buildPrompt(query)) })
                    })
                })
            })
            // جست‌وجوی گوگل برای دقت بیشتر
            put("tools", buildJsonArray {
                add(buildJsonObject { put("google_search", buildJsonObject {}) })
            })
        }.toString()
        val resp = httpPost(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            mapOf("x-goog-api-key" to apiKey),
            body,
        )
        val parts = Json.parseToJsonElement(resp).jsonObject["candidates"]?.jsonArray
            ?.firstOrNull()?.jsonObject?.get("content")?.jsonObject?.get("parts")?.jsonArray
            ?: throw IOException("پاسخ خالی از Gemini")
        val text = parts.joinToString("") { it.jsonObject["text"]?.jsonPrimitive?.content.orEmpty() }
        return parseResult(text)
    }
}

class OpenAiProvider(private val apiKey: String, private val model: String) : SpecProvider {
    override suspend fun fetch(query: String): SpecResult {
        val body = buildJsonObject {
            put("model", model)
            put("input", buildPrompt(query))
            put("tools", buildJsonArray {
                add(buildJsonObject { put("type", "web_search") })
            })
        }.toString()
        val resp = httpPost(
            "https://api.openai.com/v1/responses",
            mapOf("Authorization" to "Bearer $apiKey"),
            body,
        )
        val output: List<JsonElement> =
            Json.parseToJsonElement(resp).jsonObject["output"]?.jsonArray?.toList()
                ?: throw IOException("پاسخ خالی از OpenAI")
        val text = buildString {
            for (item in output) {
                val o = item.jsonObject
                if (o["type"]?.jsonPrimitive?.content != "message") continue
                o["content"]?.jsonArray?.forEach { c ->
                    if (c.jsonObject["type"]?.jsonPrimitive?.content == "output_text") {
                        append(c.jsonObject["text"]?.jsonPrimitive?.content.orEmpty())
                    }
                }
            }
        }
        return parseResult(text)
    }
}
