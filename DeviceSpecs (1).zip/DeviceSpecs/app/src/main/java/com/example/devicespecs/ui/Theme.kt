package com.example.devicespecs.ui

import android.content.res.Configuration
import android.os.Build
import android.text.TextUtils
import android.view.View
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

data class Appearance(
    val language: String = "system", // system | en | fa
    val themeMode: String = "system", // system | light | dark
    val accent: Long = 0xFF1565C0L, // 0 = dynamic color (Android 12+)
    val textScale: Float = 1f,
)

/** رنگ‌های پیشنهادی (صفر = پویا). */
val AccentPresets = listOf(
    0L, 0xFF1565C0L, 0xFF00897BL, 0xFF6A1B9AL, 0xFFD81B60L, 0xFFEF6C00L, 0xFF2E7D32L, 0xFF37474FL,
)

@Composable
fun AppTheme(a: Appearance, content: @Composable () -> Unit) {
    val dark = when (a.themeMode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val scheme = if (a.accent == 0L && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
    } else {
        val seed = Color(if (a.accent == 0L) 0xFF1565C0L else a.accent)
        val base = if (dark) darkColorScheme() else lightColorScheme()
        val primary = if (dark) lerp(seed, Color.White, 0.35f) else seed
        base.copy(
            primary = primary,
            onPrimary = if (dark) Color.Black else Color.White,
            primaryContainer = lerp(base.surface, seed, if (dark) 0.40f else 0.18f),
            onPrimaryContainer = base.onSurface,
            secondaryContainer = lerp(base.surface, seed, if (dark) 0.30f else 0.22f),
            onSecondaryContainer = base.onSurface,
            tertiary = if (dark) Color(0xFFFFB74D) else Color(0xFFE65100),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

/** زبان، جهت چیدمان، پوسته و اندازه متن را اعمال می‌کند و برنامه را نمایش می‌دهد. */
@Composable
fun AppEntry(vm: AppViewModel) {
    val a = vm.appearance
    val base = LocalContext.current
    val locale: Locale = remember(a.language) {
        when (a.language) {
            "fa" -> Locale("fa")
            "en" -> Locale.ENGLISH
            else -> Locale.getDefault()
        }
    }
    val cfg = remember(a.language, base) {
        Configuration(base.resources.configuration).also {
            it.setLocale(locale)
            it.setLayoutDirection(locale)
        }
    }
    val ctx = remember(a.language, base) { base.createConfigurationContext(cfg) }
    val dir = if (TextUtils.getLayoutDirectionFromLocale(locale) == View.LAYOUT_DIRECTION_RTL)
        LayoutDirection.Rtl else LayoutDirection.Ltr
    val d = LocalDensity.current

    CompositionLocalProvider(
        LocalContext provides ctx,
        LocalConfiguration provides cfg,
        LocalLayoutDirection provides dir,
        LocalDensity provides Density(d.density, d.fontScale * a.textScale),
    ) {
        AppTheme(a) { AppRoot(vm) }
    }
}
