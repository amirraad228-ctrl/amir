package com.example.devicespecs.data

data class Brand(val id: String, val color: Long, val aliases: List<String> = emptyList())

/** فهرست برندها برای تفکیک در منوی گوشی و لپ‌تاپ. نشان‌ها تک‌حرفی‌اند؛ لوگوی واقعی را می‌توانید به drawable اضافه کنید. */
object Brands {
    val phones = listOf(
        Brand("Apple", 0xFF424242, listOf("iphone", "ipad")),
        Brand("Samsung", 0xFF1428A0, listOf("galaxy")),
        Brand("Xiaomi", 0xFFFF6900, listOf("redmi", "poco")),
        Brand("Huawei", 0xFFCF0A2C),
        Brand("Honor", 0xFF00A0E9),
        Brand("Google", 0xFF4285F4, listOf("pixel")),
        Brand("OnePlus", 0xFFEB0028),
        Brand("Oppo", 0xFF1B8E5A),
        Brand("Vivo", 0xFF415FFF),
        Brand("Realme", 0xFFF5C400),
        Brand("Nothing", 0xFF212121),
        Brand("Motorola", 0xFF5C6BC0, listOf("moto")),
        Brand("Sony", 0xFF000000, listOf("xperia")),
        Brand("Nokia", 0xFF124191),
        Brand("Tecno", 0xFF0072BC),
        Brand("Infinix", 0xFF00A859),
    )

    val laptops = listOf(
        Brand("Apple", 0xFF424242, listOf("macbook")),
        Brand("Dell", 0xFF007DB8, listOf("xps", "inspiron", "latitude", "alienware", "vostro")),
        Brand("HP", 0xFF0096D6, listOf("pavilion", "spectre", "envy", "omen", "elitebook", "probook")),
        Brand("Lenovo", 0xFFE2231A, listOf("thinkpad", "ideapad", "legion", "yoga", "thinkbook")),
        Brand("Asus", 0xFF00539B, listOf("zenbook", "vivobook", "rog", "tuf", "expertbook")),
        Brand("Acer", 0xFF83B81A, listOf("aspire", "swift", "nitro", "predator", "spin")),
        Brand("MSI", 0xFFD50000, listOf("stealth", "katana", "raider", "titan")),
        Brand("Microsoft", 0xFF00A4EF, listOf("surface")),
        Brand("Razer", 0xFF00B140, listOf("blade")),
        Brand("Samsung", 0xFF1428A0, listOf("galaxy")),
        Brand("Huawei", 0xFFCF0A2C, listOf("matebook")),
        Brand("LG", 0xFFA50034, listOf("gram")),
        Brand("Gigabyte", 0xFFEF6C00, listOf("aorus", "aero")),
        Brand("Xiaomi", 0xFFFF6900),
        Brand("Honor", 0xFF00A0E9, listOf("magicbook")),
    )

    val all: List<Brand> = (phones + laptops).distinctBy { it.id }

    fun known(id: String): Brand? = all.firstOrNull { it.id.equals(id.trim(), ignoreCase = true) }

    /** برند را از نام مدل حدس می‌زند (روی کلمات کامل). */
    fun detect(name: String): String {
        val tokens = name.lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotEmpty() }
        for (b in all) {
            if (tokens.any { it == b.id.lowercase() || it in b.aliases }) return b.id
        }
        return name.trim().substringBefore(' ')
    }

    /** اولویت با برند شناخته‌شده‌ای که هوش مصنوعی داده؛ بعد حدس از روی نام. */
    fun resolve(aiBrand: String, name: String): String =
        known(aiBrand)?.id ?: detect(name).ifBlank { aiBrand.trim() }
}

/** برچسب‌های کاربری مجاز (کلیدهای ثابت انگلیسی؛ نمایش از طریق strings). */
object Usage {
    val phone = listOf("gaming", "photography", "battery", "office", "budget")
    val laptop = listOf("gaming", "office", "student", "creative", "programming", "portable", "budget")
    val all: List<String> = (phone + laptop).distinct()
}
