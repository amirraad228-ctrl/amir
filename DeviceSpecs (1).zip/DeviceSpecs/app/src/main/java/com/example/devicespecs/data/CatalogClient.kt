package com.example.devicespecs.data

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer

/** یک دستگاه در کاتالوگ مشترک (قالب رد و بدل با سرور). */
@Serializable
data class CatalogDevice(
    val key: String = "",
    val name: String = "",
    val brand: String = "",
    val category: String = "other",
    val specs: Map<String, Map<String, String>> = emptyMap(),
    val sources: List<String> = emptyList(),
    val usage: List<String> = emptyList(),
    val updatedAt: Long = 0,
    /** شماره ترتیب سمت سرور؛ برای دریافت فقط موارد جدید. */
    val seq: Long = 0,
)

internal suspend fun httpGet(url: String, headers: Map<String, String>): String =
    withContext(Dispatchers.IO) {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = (stream?.bufferedReader()?.use { it.readText() }).orEmpty()
            if (code !in 200..299) throw IOException("HTTP $code: ${text.take(200)}")
            text
        } finally {
            c.disconnect()
        }
    }

class CatalogClient(base: String, private val token: String) {
    private val root = base.trim().trimEnd('/')

    init {
        require(root.startsWith("https://")) { "Catalog URL must start with https://" }
    }

    private fun headers(): Map<String, String> =
        if (token.isBlank()) emptyMap() else mapOf("X-Api-Key" to token)

    suspend fun pull(sinceSeq: Long, limit: Int = PAGE): List<CatalogDevice> {
        val text = httpGet("$root/v1/devices?since=$sinceSeq&limit=$limit", headers())
        return AppJson.decodeFromString(ListSerializer(CatalogDevice.serializer()), text)
    }

    suspend fun push(items: List<CatalogDevice>) {
        val body = AppJson.encodeToString(ListSerializer(CatalogDevice.serializer()), items)
        httpPost("$root/v1/devices", headers(), body)
    }

    companion object {
        const val PAGE = 500
    }
}
