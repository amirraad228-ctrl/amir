package com.example.devicespecs.data

import android.content.Context

/** تنظیمات کاربر: هوش مصنوعی، رضایت اینترنت، کاتالوگ مشترک، زبان و ظاهر. */
class SettingsStore(context: Context) {
    private val p = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var provider: String
        get() = p.getString("provider", "gemini") ?: "gemini"
        set(v) = p.edit().putString("provider", v).apply()

    var apiKey: String
        get() = p.getString("apiKey", "") ?: ""
        set(v) = p.edit().putString("apiKey", v.trim()).apply()

    var model: String
        get() = p.getString("model", "") ?: ""
        set(v) = p.edit().putString("model", v.trim()).apply()

    /** کاربر اجازه داده برنامه از اینترنت و هوش مصنوعی آنلاین استفاده کند. */
    var consent: Boolean
        get() = p.getBoolean("consent", false)
        set(v) = p.edit().putBoolean("consent", v).apply()

    // --- کاتالوگ مشترک ---
    var catalogUrl: String
        get() = p.getString("catalogUrl", "") ?: ""
        set(v) = p.edit().putString("catalogUrl", v.trim()).apply()

    var catalogToken: String
        get() = p.getString("catalogToken", "") ?: ""
        set(v) = p.edit().putString("catalogToken", v.trim()).apply()

    /** اگر روشن باشد، مدل‌های جست‌وجوشده (فقط مشخصات فنی) به کاتالوگ فرستاده می‌شوند. */
    var shareToCatalog: Boolean
        get() = p.getBoolean("shareToCatalog", false)
        set(v) = p.edit().putBoolean("shareToCatalog", v).apply()

    var lastSyncSeq: Long
        get() = p.getLong("lastSyncSeq", 0L)
        set(v) = p.edit().putLong("lastSyncSeq", v).apply()

    var lastPush: Long
        get() = p.getLong("lastPush", 0L)
        set(v) = p.edit().putLong("lastPush", v).apply()

    // --- ظاهر ---
    /** system | en | fa */
    var language: String
        get() = p.getString("language", "system") ?: "system"
        set(v) = p.edit().putString("language", v).apply()

    /** system | light | dark */
    var themeMode: String
        get() = p.getString("themeMode", "system") ?: "system"
        set(v) = p.edit().putString("themeMode", v).apply()

    /** رنگ اصلی (ARGB)؛ صفر یعنی رنگ پویای اندروید ۱۲+. */
    var accent: Long
        get() = p.getLong("accent", 0xFF1565C0L)
        set(v) = p.edit().putLong("accent", v).apply()

    var textScale: Float
        get() = p.getFloat("textScale", 1f)
        set(v) = p.edit().putFloat("textScale", v).apply()

    fun effectiveModel(): String =
        model.ifBlank { if (provider == "openai") "gpt-4o" else "gemini-2.5-flash" }
}
