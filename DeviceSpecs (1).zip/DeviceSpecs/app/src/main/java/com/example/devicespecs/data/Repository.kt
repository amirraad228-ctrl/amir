package com.example.devicespecs.data

class NoKeyException : Exception()

class NotFoundException : Exception()

class Repository(
    private val dao: DeviceDao,
    private val settings: SettingsStore,
) {
    fun observeAll() = dao.observeAll()

    suspend fun suggest(q: String): List<DeviceEntity> =
        dao.suggest(normalizeKey(q), q.trim())

    /** جست‌وجوی سریع در کتابخانه: تطابق دقیق، یا تنها یک مورد مشابه. */
    suspend fun findLocal(q: String): DeviceEntity? {
        val k = normalizeKey(q)
        if (k.isEmpty()) return null
        dao.byKey(k)?.let { return it }
        val m = dao.suggest(k, q.trim())
        return if (m.size == 1 && k.length >= 4) m[0] else null
    }

    suspend fun touch(d: DeviceEntity) = dao.touch(d.id, System.currentTimeMillis())

    suspend fun delete(d: DeviceEntity) = dao.delete(d)

    fun canGoOnline(): Boolean = settings.consent && settings.apiKey.isNotBlank()

    /** جست‌وجوی آنلاین با هوش مصنوعی و ذخیره/به‌روزرسانی در کتابخانه. */
    suspend fun fetchOnline(q: String, existing: DeviceEntity? = null): DeviceEntity {
        if (settings.apiKey.isBlank()) throw NoKeyException()
        val provider: SpecProvider =
            if (settings.provider == "openai") OpenAiProvider(settings.apiKey, settings.effectiveModel())
            else GeminiProvider(settings.apiKey, settings.effectiveModel())

        val r = provider.fetch(q)
        if (r.error != null || r.specs.isEmpty()) throw NotFoundException()

        val name = r.name.ifBlank { q.trim() }
        val key = normalizeKey(name)
        val old = existing ?: dao.byKey(key)
        val now = System.currentTimeMillis()
        val usage = r.usage.map { it.trim().lowercase() }.filter { it in Usage.all }.distinct()
        val e = DeviceEntity(
            id = old?.id ?: 0,
            key = key,
            name = name,
            brand = Brands.resolve(r.brand, name),
            category = r.category,
            specsJson = encodeSpecs(r.specs),
            sourcesJson = encodeSources(r.sources),
            usage = usage.joinToString(","),
            fetchedAt = now,
            lastUsedAt = now,
            useCount = (old?.useCount ?: 0) + 1,
        )
        val id = dao.upsert(e)
        return e.copy(id = old?.id ?: id)
    }

    /** چند مدل قدیمی‌تر (پراستفاده‌ترها اول) را با هوش مصنوعی تازه می‌کند. تعداد محدود است تا هزینه API بالا نرود. */
    suspend fun refreshStale(limit: Int, staleMs: Long): Int {
        if (!canGoOnline()) return 0
        val now = System.currentTimeMillis()
        val stale = dao.all()
            .filter { now - it.fetchedAt > staleMs }
            .sortedByDescending { it.useCount }
            .take(limit)
        var n = 0
        for (d in stale) {
            try {
                fetchOnline(d.name, d)
                n++
            } catch (_: Exception) {
                // یک مورد ناموفق بقیه را متوقف نمی‌کند.
            }
        }
        return n
    }

    // ------------------------------------------------------------------ کاتالوگ مشترک

    private fun client() = CatalogClient(settings.catalogUrl, settings.catalogToken)

    /** مدل‌های تازه‌ای را که کاربران دیگر اضافه کرده‌اند می‌گیرد و در کتابخانه ادغام می‌کند. تعداد مدل‌های جدید را برمی‌گرداند. */
    suspend fun pull(): Int {
        if (settings.catalogUrl.isBlank()) return 0
        val client = client()
        var since = settings.lastSyncSeq
        var added = 0
        val now = System.currentTimeMillis()
        for (page in 0 until 5) {
            val batch = client.pull(since)
            for (r in batch) {
                since = maxOf(since, r.seq)
                val key = normalizeKey(r.name)
                if (key.isEmpty() || r.specs.isEmpty()) continue
                val local = dao.byKey(key)
                if (local == null || r.updatedAt > local.fetchedAt) {
                    dao.upsert(
                        DeviceEntity(
                            id = local?.id ?: 0,
                            key = key,
                            name = r.name,
                            brand = Brands.resolve(r.brand, r.name),
                            category = r.category,
                            specsJson = encodeSpecs(r.specs),
                            sourcesJson = encodeSources(r.sources),
                            usage = r.usage.filter { it in Usage.all }.joinToString(","),
                            fetchedAt = r.updatedAt,
                            lastUsedAt = local?.lastUsedAt ?: now,
                            useCount = local?.useCount ?: 0,
                        )
                    )
                    if (local == null) added++
                }
            }
            settings.lastSyncSeq = since
            if (batch.size < CatalogClient.PAGE) break
        }
        return added
    }

    /** مدل‌های جدید/به‌روزشده این دستگاه را (فقط مشخصات فنی) به کاتالوگ می‌فرستد؛ فقط اگر کاربر اجازه داده باشد. */
    suspend fun pushPending() {
        if (!settings.shareToCatalog || settings.catalogUrl.isBlank()) return
        val pending = dao.all()
            .filter { it.fetchedAt > settings.lastPush && it.specs().isNotEmpty() }
            .sortedBy { it.fetchedAt }
            .take(100)
        if (pending.isEmpty()) return
        client().push(
            pending.map {
                CatalogDevice(
                    key = it.key, name = it.name, brand = it.brand, category = it.category,
                    specs = it.specs(), sources = it.sources(), usage = it.usageTags(),
                    updatedAt = it.fetchedAt,
                )
            }
        )
        settings.lastPush = pending.maxOf { it.fetchedAt }
    }

    suspend fun sync(): Int {
        val added = pull()
        pushPending()
        return added
    }
}
